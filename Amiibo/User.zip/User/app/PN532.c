#include <PN532.h>


static uint8_t DW[] = {0x00,0x00,0x00,0x01};
static uint8_t DR[] = {0x00,0x00,0x00,0x11};
static uint8_t SR[] = {0x00,0x00,0x00,0x10};


static uint8_t  PREAMBLE[] = {0x00};
static uint8_t  START_CODE[] = {0x00,0xFF};


uint8_t PN532_test(PN532_ctx_t* PN532)
{
    if(PN532 == NULL) 
    {
        return 0;
    }
    return 0;
}
