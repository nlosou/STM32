#ifndef PN532_H_
#define PN532_H_
#include "spi_port.h"
#include "middleware/spi_select_opp.h"


typedef struct {
    spi_port_t *port;
    spi_select_port_t *cs;
    uint16_t CS_PIN;
    uint8_t bit_order;
}PN532_ctx_t;


#endif
